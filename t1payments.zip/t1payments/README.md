# The Governor

Custom WordPress Starter Theme By Adlava for custom development projects that are Webflow based.  The Governor succeeds HoneyBadger, adlava's initial flagship development starter theme.


## The Governor's Namesake
The Governor theme is named after the character in The Walking Dead Graphic Novel & TV Series.

### To Dos For Next Versions
1. Add WP Dash Color Schemes
	- My Alien Scheme
	- Justin's Adlava Scheme
2. Add Adlava Welcome Message
3. Add Adlava Blog Feed Dashboard Widget
4. Add Login Customizer to Theme Options Panel

## Things Completed By Karl
1. This is the fixed version of Governor.
2. All errors are fixed.
3. Company references are removed from theme.
4. ReUploaded original Governor theme preview image.
5. Broken links are fixed.
