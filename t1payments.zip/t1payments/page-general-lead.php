<?php
/*
 Template Name: General Lead Page Template
*/
get_header();
$general_lead_text = get_post_meta( get_the_id(), 'general_lead_text', true );
$key_features_text = get_post_meta( get_the_id(), 'key_features_info', true );
?>

<div class="hero home" style="background-image: linear-gradient(180deg, rgba(51, 51, 102, .88), rgba(51, 51, 102, .88)), url('https://t1payments.com/wp-content/uploads/2018/09/general-lead-hero.jpg');height: 100% !important;padding-top: 11em; padding-bottom: 4em;">
    <div class="content-wrapper home-hero general-leads" data-ix="show-solid-header" style="top: 20%;position:relative;left:0;right:0;">
        <div class="w-row">
            <div class="col p-left-o w-col w-col-6">
                <div class="contact-text-block p-right-40">
                    <h3 class="left-page-title" style="font-size: 2.5rem;line-height: 3rem;letter-spacing: 3px;"><?php echo the_title(); ?></h3>
                    <div class="text-divider"></div>
                    <br>
                    <div class="home-slogan sub-slogan line-height22" style="max-width: 95%;">
                        <?php echo $general_lead_text; ?>
                    </div>
                    <br>

                    <h3 style="text-align: center;color: white;font-size: 1.5em;margin-bottom: .5em">KEY FEATURES</h3>
                    <div class="home-slogan sub-slogan line-height22" style="text-align: center;max-width:100%;">
                        <?php echo $key_features_text; ?>
                        &nbsp;
                        <br><img style="width: 175px;margin-top: 2em;" src="/wp-content/uploads/2018/09/Magento-logo-white.png"><img style="width: 20%;margin-left: 2em;margin-top: 2em;margin-right:1em;" src="/wp-content/uploads/2018/09/NMI_Logo_Small.png">
                        <img src="/wp-content/uploads/2018/09/shopify-logo-white-e1536767378293.png"><img style="margin-top: 1em;" src="/wp-content/uploads/2018/09/logo-woocommerce-white-e1536767402916.png">
                    </div>

                </div>
            </div>
            <div class="w-col w-col-6">
                <div class="in-hero-form-wrap w-form" style="padding: 20px;">
                    <?php echo do_shortcode('[gravityform id="10" title="false" description="false"]');?>
                </div>
            </div>
        </div>
    </div>
</div>

<a class="down-arrow w-inline-block" href="#benefits"></a>

<div class="page-section" id="benefits">
    <div class="centered-content content-wrapper">
        <div class="section-heading-block">
            <h2 class="margin-btm-20 section-heading"><?php echo get_post_meta( get_the_id(), 'general_leads_main_text', true ); ?></h2>
            <div class="text-divider"></div>
        </div>
        <div class="anim-cont margin-btm-50 row w-row">
            <?php
            for ($i=1; $i <=4 ; $i++) {
                $general_leads_image = get_post_meta( get_the_id(), 'general_leads_image_'.$i, true );
                $general_leads_image_url = wp_get_attachment_image_src($general_leads_image, 'home_main')[0];
                $general_leads_image_obj = wp_prepare_attachment_for_js( $general_leads_image );
                ?>
                <div class="col w-col w-col-3 w-col-medium-6">
                    <div class="anim-item benefit-block">
                        <img alt="<?php echo $general_leads_image_obj['alt'] ? $general_leads_image_obj['alt'] : 'This is the image alt'; ?>" title="<?php echo $general_leads_image_obj['title'] ? $general_leads_image_obj['title'] : 'This is the image title'; ?>" class="benefit-icon" src="<?php echo $general_leads_image_url; ?>">
                        <div class="benefit-title"><?php echo get_post_meta( get_the_id(), 'general_leads_main_name_'.$i, true )?></div>
                        <div><?php echo get_post_meta( get_the_id(), 'general_leads_main_copy_'.$i, true )?></div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<div class="page-section" style="background-color: #FF9933;">
    <div class="centered-content content-wrapper" style="max-width: 1600px;">
        <div class="section-heading-block">
            <h2 class="margin-btm-20 section-heading" style="color:white;"><?php echo get_post_meta( get_the_id(), 'general_leads_industries_header', true ); ?></h2>
            <div class="home-slogan sub-slogan line-height22" style="color:white; max-width:100%;font-weight:700;"><?php echo get_post_meta( get_the_id(), 'general_leads_industries_content', true ); ?></div>
            <div style="width: 50%;margin-left: auto !important;margin-right: auto !important;">
                <?php echo do_shortcode('[gravityform id="9" title="false" description="false"]');?>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
