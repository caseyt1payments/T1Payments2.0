<?php
/*
 * Governor Images
 *
 * https://developer.wordpress.org/reference/functions/add_image_size/
 */

/*function governor_theme_images() {
    add_image_size( 'example-thumb', 300 ); // 300 pixels wide (and unlimited height)
    add_image_size( 'example-cropped-thumb', 220, 180, true ); // (cropped)
    add_image_size( 'example-cropped-hero', 1080, 350, true ); // (cropped)
}
add_action( 'after_setup_theme', 'governor_theme_images' );*/

?>