<?php
/*
 * Full Width Page Template Architecture
 * Meta Boxes, Fields, etc.
 */

?>